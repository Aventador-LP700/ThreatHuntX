"""ThreatHuntX local learning lab."""
